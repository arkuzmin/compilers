package ru.bmstu.arkuzmin.model;

public class App {
	public static void main(String[] args) {
		String input = "AB+C/";

		for (String str:  CodeGenerator.generateInstructions(input)) {
			System.out.println(str);
		}
	}
}
