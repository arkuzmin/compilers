package ru.bmstu.arkuzmin.model;

import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;

public class CodeGenerator {
	
	private static final String LOAD = "L";
	private static final String ADD = "A";
	private static final String SUB = "S";
	private static final String MUL = "M";
	private static final String DIV = "D";
	private static final String NEG = "N";
	private static final String STORE = "ST";
	
	private static int var = 1;
	
	private static Set<Character> operands;
	
	static {
		operands.add('+');
		operands.add('/');
		operands.add('-');
		operands.add('*');
		operands.add('@');
	}
	
	
	public static List<String> generateInstructions(String input) {
		
		if (input == null || "".equals(input)) {
			return null;
		}
		
		List<String> instructions = new LinkedList<String>();
		Stack<Character> stack = new Stack<Character>();
		
		for (int i = 0; i < input.length(); i++) {
			// �������
			char ch = input.charAt(i);
			if (Character.isLetter(ch)) {
				stack.push(ch);
			}
			
			else if (operands.contains(ch)) {
				if (operands.contains(stack.peek())) {
					
				} else {
					char b = stack.pop();
					char a = stack.pop();
					instructions.add(LOAD + " " + a);
					instructions.add(ADD + " " + b);
				}
			}
		}
		
	
		return instructions;
	}
	
}
