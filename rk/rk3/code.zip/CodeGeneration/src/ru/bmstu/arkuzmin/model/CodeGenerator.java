package ru.bmstu.arkuzmin.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.Stack;

public class CodeGenerator {
	
	private static final String LOAD = "L";
	private static final String STORE = "ST";
	
	private static int var = 1;
	
	
	

	
	private static enum Operators {
		ADD("A", "+"),
		DIV("D", "/"),
		SUB("S", "-"),
		MUL("M", "*"),
		NEG("N", "@");
		
		private static Set<String> signs = new HashSet<String>();
		
		static {
			signs.add("+");
			signs.add("/");
			signs.add("-");
			signs.add("*");
			signs.add("@");
		}
		
		String letter;
		String sign;
		
		Operators(String letter, String sign) {
			this.letter = letter;
			this.sign = sign;
		}
		
		public String getLetter() {
			return letter;
		}
		
		public String getSign() {
			return sign;
		}
		
		public static Set<String> getSigns() {
			return signs;
		}
		
		public static String getLetter(String sign) {
			for (Operators op : values()) {
				if (op.getSign().equals(sign)) {
					return op.getLetter();
				}
			}
			return null;
		}
		
	}
	
	
	public static List<String> generateInstructions(String input) {
		
		if (input == null || "".equals(input)) {
			return null;
		}
		
		List<String> instructions = new LinkedList<String>();
		Stack<String> stack = new Stack<String>();
		
		for (int i = 0; i < input.length(); i++) {
			// �������
			char ch = input.charAt(i);
			if (Character.isLetter(ch)) {
				
				if (stack.isEmpty()) {
					stack.push(String.valueOf(ch));
				} else {
					if (Character.isLetter(stack.peek().charAt(0)) || stack.peek().charAt(0) == '$') {
						stack.push(String.valueOf(ch));
					} else if (Operators.getSigns().contains(stack.peek())) {
						List<String> ops = new ArrayList<String>(3);
						while (Operators.getSigns().contains(stack.peek())) {
							ops.add(0, stack.pop());
						}
						if (!ops.isEmpty()) {
							String b = stack.pop();
							String a = stack.pop();
							String op = ops.remove(0);
							instructions.add(LOAD + " " + a);
							instructions.add(Operators.getLetter(op) + " " + b);
							
						}
						if (ops.isEmpty()) {
							instructions.add(STORE + " $" + var);
							stack.push("$" + var);
							stack.push(String.valueOf(ch));
							var++;
						} else {
							String b = null;
							for (String op : ops) {
								b = stack.pop();
								instructions.add(Operators.getLetter(op) + " " + b);
							}
							instructions.add(STORE + " " + b);
							stack.push(b);
							stack.push(String.valueOf(ch));
						}
					}
				}
			}
			
			else if (Operators.getSigns().contains(String.valueOf(ch))) {
				stack.push(String.valueOf(ch));
			}
		}
		
		if (!stack.isEmpty()) {
			if (Operators.getSigns().contains(stack.peek())) {
				List<String> ops = new ArrayList<String>(3);
				while (Operators.getSigns().contains(stack.peek())) {
					ops.add(0, stack.pop());
				}
				if (!ops.isEmpty()) {
					String b = stack.pop();
					String a = stack.pop();
					String op = ops.remove(0);
					instructions.add(LOAD + " " + a);
					instructions.add(Operators.getLetter(op) + " " + b);
					
				}
				if (!ops.isEmpty()) {
					String b = null;
					for (String op : ops) {
						b = stack.pop();
						instructions.add(Operators.getLetter(op) + " " + b);
					}
				}
			}
		}
		
	
		return instructions;
	}
	
}
