package ru.bmstu.arkuzmin.view;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import ru.bmstu.arkuzmin.model.CodeGenerator;

public class View {

	private JFrame frame;
	private JTextArea output;
	private JTextArea input;
	private JButton btnNewButton;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					View window = new View();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public View() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setTitle("\u041A\u0443\u0437\u044C\u043C\u0438\u043D \u0410\u0440\u0442\u0435\u043C, \u0418\u04237-29. \u0420\u041A\u21163");
		frame.setBounds(100, 100, 450, 533);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(10, 11, 414, 101);
		frame.getContentPane().add(panel);
		panel.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane = new JScrollPane();
		panel.add(scrollPane, BorderLayout.CENTER);
		
		input = new JTextArea();
		input.setText("AB+CD+EF++GH+++\r\nAB*C*D*\r\nAB+CD+EF++GH+++AB*C*D**");
		scrollPane.setViewportView(input);
		
		btnNewButton = new JButton("\u041F\u043E\u043B\u0443\u0447\u0438\u0442\u044C \u0438\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String in = input.getText();
				String[] ins = in.split("\r\n");
				for (String i : ins ) {
					List<String> out = CodeGenerator.generateInstructions(i);
					for (String o : out) {
						output.setText(output.getText() + o + "\n");
					}
					output.setText(output.getText() + "-----------------------------\n");
				}
				
			}
		});
		btnNewButton.setBounds(262, 123, 162, 23);
		frame.getContentPane().add(btnNewButton);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 157, 414, 294);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(new BorderLayout(0, 0));
		
		JScrollPane scrollPane_1 = new JScrollPane();
		panel_1.add(scrollPane_1, BorderLayout.CENTER);
		
		output = new JTextArea();
		scrollPane_1.setViewportView(output);
		
		JButton button = new JButton("\u041E\u0447\u0438\u0441\u0442\u0438\u0442\u044C");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				input.setText("");
				output.setText("");
			}
		});
		button.setBounds(262, 462, 162, 23);
		frame.getContentPane().add(button);
	}
}
